# -*- coding: utf-8 -*-
# Author : Peter Wu

from odoo import models, api


class ReportPurchaseRequire(models.AbstractModel):
    _name = 'report.neweb_report.purchase_require_report_custom'



    @api.multi
    def render_html(self, docids, data=None):
        self.model = self.env.context.get('active_model')
        myid = self.env.context.get('active_id')
        docs = self.env['neweb.require_purchase'].sudo().browse(docids)

        docargs = {
            'doc_ids': docids,
            'doc_model': self.model,
            'docs': docs,
        }
        return self.env['report'].sudo().render('neweb_report.purchase_require_report_custom', values=docargs)
