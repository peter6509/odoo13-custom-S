# _*_ coding: utf-8 _*_

from odoo import models, api


class ReportProjectCustompreview(models.AbstractModel):
    _name = 'report.neweb_report.neweb_custom_data_report_preview'



    @api.multi
    def render_html(self, docids, data=None):
        self.model = self.env.context.get('active_model')
        myid = self.env.context.get('active_id')
        docs = self.env['neweb.project'].sudo().browse(docids)

        docargs = {
            'doc_ids': docids,
            'doc_model': self.model,
            'docs': docs,
        }
        return self.env['report'].sudo().render('neweb_report.neweb_custom_data_report_preview', values=docargs)


