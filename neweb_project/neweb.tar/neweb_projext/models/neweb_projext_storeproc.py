# -*- coding: utf-8 -*-
# Author : Peter Wu


from odoo import models,fields,api


class newebprojextstoreproc(models.Model):
    _name = "neweb_projext.storeproc"


    @api.model_cr
    def init(self):

        self._cr.execute("""drop function if exists genstockout_projno(projid int) cascade;""")
        self._cr.execute("""create or replace function genstockout_projno(projid int) returns void as $BODY$
            declare 
              ncount int ;
              myprojno VARCHAR;
              mysaleno VARCHAR ;
            begin 
              myprojno := 'None' ;
              mysaleno := 'None' ;
              select count(*) into ncount from neweb_project where id = projid ;
              if ncount > 0 then
                 select name,sale_no into myprojno,mysaleno from neweb_project where id=projid ; 
              end if ;
              select count(*) into ncount from stock_picking where origin like mysaleno ;
              if ncount > 0 then 
                 update stock_picking set stockout_proj_no=myprojno where origin like mysaleno ;
              end if ;
            end; $BODY$
            LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists genallstockoutprojno() cascade;""")
        self._cr.execute("""create or replace function genallstockoutprojno() returns void as $BODY$
             declare 
               proj_cur refcursor ;
               proj_rec record ;
               ncount int ;
             begin 
               open proj_cur for select name,sale_no from neweb_project ;
               loop
                 fetch proj_cur into proj_rec ;
                 exit when not found ;
                 select count(*) into ncount from stock_picking where origin like proj_rec.sale_no ;
                 if ncount > 0 then
                    update stock_picking set stockout_proj_no = proj_rec.name where origin like proj_rec.sale_no ; 
                 end if ;
               end loop ;
               close proj_cur ;
             end; $BODY$
             LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists genmainrec(myprojid int) cascade;""")
        self._cr.execute("""create or replace function genmainrec(myprojid int) returns void as $BODY$
             declare 
               ncount int ;
               mycallserviceresponse int ;
               myroutinemaintenancenew int ;
               mymainservicerulenew int ;
               mysaleno varchar;
             begin 
               select count(*) into ncount from neweb_project where id=myprojid and sale_no is not null ;
               if ncount > 0 then
                  select sale_no into mysaleno from neweb_project where id=myprojid ;
                  select call_service_response1,routine_maintenance_new,main_service_rule_new into 
                     mycallserviceresponse,myroutinemaintenancenew,mymainservicerulenew from sale_order
                     where name like mysaleno ; 
                  if mycallserviceresponse is not null then 
                     update neweb_project set call_service_response=mycallserviceresponse where id=myprojid ;
                  end if ;  
                  if myroutinemaintenancenew is not null then 
                     update neweb_project set routine_maintenance_new=myroutinemaintenancenew where id=myprojid ;
                  end if ;
                  if mymainservicerulenew is not null then 
                     update neweb_project set main_service_rule_new=mymainservicerulenew where id=myprojid ;
                  end if ;
               end if ;
             end; $BODY$
             LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists gencreditlimit(projid int) cascade""")
        self._cr.execute("""create or replace function gencreditlimit(projid int) returns void as $BODY$
             declare 
               mycredit FLOAT;
               mycusid int;
               mycreditmemo varchar;
             begin 
               select cus_name into mycusid from neweb_project where id = projid ;
               select round(credit_limit) into mycredit from res_partner where id=mycusid ;
               mycreditmemo := concat(to_char(mycredit,'999,999,999'),'  元');
               update neweb_project set proj_info_memo=mycreditmemo where id = projid ;
             end ;$BODY$
             LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists check_cusproject(projid int) cascade""")
        self._cr.execute("""create or replace function check_cusproject(projid int) returns Boolean as $BODY$
             declare 
               ncount int;
               myresult Boolean;
             begin 
               select count(*) into ncount from neweb_project where id=projid and cus_project is null ;
               if ncount = 0 then 
                  myresult := True ;
               else 
                  myresult := False ;
               end if ;
               return myresult ;
             end ; $BODY$
             LANGUAGE plpgsql ;""")

        self._cr.execute("""drop function if exists check_projectname(saleid int) cascade""")
        self._cr.execute("""create or replace function check_projectname(saleid int) returns Boolean as $BODY$
             declare 
                ncount int;
                myresult Boolean;
             begin 
               select count(*) into ncount from sale_order where id=saleid and project_name is null ;
               if ncount = 0 then 
                  myresult := True ;
               else 
                  myresult := False ;
               end if ;
               return myresult ;
             end;$BODY$
             LANGUAGE plpgsql ;""")

        self._cr.execute("""drop function if exists getpayterm(cusid int) cascade""")
        self._cr.execute("""create or replace function getpayterm(cusid int) returns CHAR as $BODY$
            declare 
              ncount int;
              mytype CHAR;
              mypayterm varchar;
            begin 
              select count(*) into ncount from res_partner where id=cusid ;
              mytype := '0';
              if ncount >0 then
                 select pay_term into mypayterm from res_partner where id=cusid ;
                 if mypayterm like '%30%' then 
                    mytype := '1' ;
                 elsif mypayterm like '%45%' then 
                    mytype := '2' ;
                 elsif mypayterm like '%60%' then 
                    mytype := '3' ;
                 elsif mypayterm like '%90%' then 
                    mytype := '4' ;
                 elsif mypayterm like '%120%' then 
                    mytype := '5' ;
                 end if ;
              end if ;   
              return mytype ;              
            end;$BODY$
            LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists hasproj(saleorderid int) cascade""")
        self._cr.execute("""create or replace function hasproj(saleorderid int) returns Boolean as $BODY$
            declare 
              ncount int ;
              saleno varchar ;
              myresult Boolean ;
            begin
              myresult := False ;
              select name into saleno from sale_order where id=saleorderid ;
              select count(*) into ncount from neweb_project where sale_no=saleno ;
              if ncount > 0 then
                 myresult := True ;
              end if ;
              return myresult ;
            end ; $BODY$
            LANGUAGE plpgsql ; 
             """)

        self._cr.execute("""drop function if exists setpaymentterm(projid int) cascade""")
        self._cr.execute("""create or replace function setpaymentterm(projid int) returns void as $BODY$
            declare 
               ncount int ;
               mysaleno varchar ;
               paymentterm INT;
            begin 
               select payment_term_new into paymentterm from sale_order where name like (select sale_no from neweb_project where id=projid);
               if paymentterm is not null then 
                  update neweb_project set proj_pay1=paymentterm where id=projid ;
               end if ;
            end;$BODY$
            LANGUAGE plpgsql;""")

        self._cr.execute("""drop function if exists hasdisamount(saleid int) cascade;""")
        self._cr.execute("""create or replace function hasdisamount(saleid int) returns Boolean as $BODY$
            declare 
              myres Boolean ;
              ncount INT;
            BEGIN 
              select count(*) into ncount from sale_order where id=saleid and discount_amount > 0 ;
              if ncount > 0 then 
                 myres := TRUE ;
              else 
                 myres := FALSE ;
              end if ;
              return myres ;
            END;$BODY$
            LANGUAGE plpgsql;""")
               
