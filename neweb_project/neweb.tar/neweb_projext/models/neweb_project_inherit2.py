# -*- coding: utf-8 -*-
# Author : Peter Wu


from odoo import models,fields,api


class newebprojectinherit2(models.Model):
    _inherit = "sale.order"

    credit_limit = fields.Float(string=u"信用額度")
    credit_rulelist = fields.Text(string=u"信用條件")

    @api.onchange('partner_id')
    def onchangepartner(self):
        myrec = self.env['res.partner'].search([('id','=',self.partner_id.id)])
        if myrec :
           self.credit_limit = myrec.credit_limit
           self.credit_rulelist = myrec.credit_rulelist