# -*- coding: utf-8 -*-
# Author : Peter Wu


from odoo import models ,fields , api, _


class saleinherit(models.Model):
    _inherit = "sale.order"

    call_service_response1 = fields.Many2one('neweb_base.sla', domain=[('disabled', '=', False)], string=u"叫修時效",track_visibility='always')