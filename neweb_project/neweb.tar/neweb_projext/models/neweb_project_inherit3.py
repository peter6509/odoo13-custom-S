# -*- coding: utf-8 -*-
# Author : Peter Wu


from odoo import models,fields,api


class newebprojectinherit3(models.Model):
    _inherit = "neweb.projsaleitem"


    prod_stockoutnum = fields.Float(string=u"已出貨數量",default=0)
    prod_stockout_complete = fields.Boolean(string=u"出貨完成否",default=False)


    @api.model
    def create(self, vals):

        res = super(newebprojectinherit3, self).create(vals)
        self.env.cr.execute("""update neweb_project set purchase_yn=False where id=%d""" % res.saleitem_id.id)
        return res