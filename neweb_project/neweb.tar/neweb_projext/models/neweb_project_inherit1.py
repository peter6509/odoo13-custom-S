# -*- coding: utf-8 -*-
# Author : Peter Wu


from odoo import models,fields,api


class newebprojectextinherit1(models.Model):
    _inherit = ["res.partner"]


    credit_rulelist = fields.Text(string=u"信用條件")