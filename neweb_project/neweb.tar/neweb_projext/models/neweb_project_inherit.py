# -*- coding: utf-8 -*-
# Author : Peter Wu

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class newebprojext(models.Model):
    _inherit = "neweb.project"

    call_service_response = fields.Many2one('neweb_base.sla', domain=[('disabled', '=', False)], string=u"叫修時效",
                                            track_visibility='always')
    main_service_rule_new = fields.Many2one('neweb.main_service_rule', string=u"維護服務時段")
    routine_maintenance_new = fields.Many2one('neweb.routine_maintenance', string=u"定期維護條款")
    proj_pay1 = fields.Many2one('neweb.payment_term_rule', string=u"付款條件")
    company_id = fields.Many2one('res.company', string="My Company", default=1)

    @api.model
    def create(self, vals):
        res = super(newebprojext, self).create(vals)
        self.env.cr.execute("""select check_cusproject(%d)""" % res.id)
        myresult = self.env.cr.fetchone()
        # if not myresult[0]:
        #     raise UserError("客戶專案/標案名稱不能空白!!")
        self.env.cr.execute("""select genstockout_projno(%d)""" % res.id)
        self.env.cr.execute("""select genmainrec(%d)""" % res.id)
        self.env.cr.execute("""select gencreditlimit(%d)""" % res.id)
        self.env.cr.execute("""select setpaymentterm(%d)""" % res.id)
        return res

    @api.multi
    def write(self, vals):
        res = super(newebprojext, self).write(vals)
        self.env.cr.execute("""select check_cusproject(%d)""" % self.id)
        myresult = self.env.cr.fetchone()
        # if not myresult[0]:
        #     raise UserError("客戶專案/標案名稱不能空白!!")
        self.env.cr.execute("""select genstockout_projno(%d)""" % self.id)
        self.env.cr.execute("""select genmainrec(%d)""" % self.id)
        self.env.cr.execute("""select gencreditlimit(%d)""" % self.id)
        self.env.cr.execute("""select setpaymentterm(%d)""" % self.id)

        return res


class newebprojextsaleorder(models.Model):
    _inherit = "sale.order"

    @api.model
    def create(self, vals):
        res = super(newebprojextsaleorder, self).create(vals)
        self.env.cr.execute("""select check_projectname(%d)""" % res.id)
        myresult = self.env.cr.fetchone()
        if not myresult[0]:
            raise UserError("專案名稱不能空白!!")
        return res

    @api.multi
    def write(self, vals):
        res = super(newebprojextsaleorder, self).write(vals)
        self.env.cr.execute("""select check_projectname(%d)""" % self.id)
        myresult = self.env.cr.fetchone()
        if not myresult[0]:
            raise UserError("專案名稱不能空白!!")

        return res

    @api.onchange('partner_id')
    def onchange_partnerid(self):
        self.env.cr.execute("""select getpayterm(%d)""" % self.partner_id.id)
        myresult = self.env.cr.fetchone()
        if myresult[0] != '0':
            self.open_account_day = myresult[0]

    def cancel_done(self):
        myid = self.env.context.get('saleorderid')
        myrec = self.env['sale.order'].search([('id', '=', myid)])
        self.env.cr.execute("""select hasproj(%d)""" % myid)
        myresult = self.env.cr.fetchone()
        if myresult[0]:
            raise UserError("請先刪除專案成本分析,才能解鎖")
        myrec.write({'state': 'draft'})


# class newebprojextrespartner(models.Model):
#     _inherit = "res.partner"
#
#     credit_rule_memo = fields.Text(string=u"信用條件")