# -*- coding: utf-8 -*-
# Author : Peter Wu



{
    'name': u'<15>.NEWEB 專案管理擴充模組',
    'license': 'LGPL-3',
    'version': '1.0',
    'category': 'Project EXT management',
    "website": "http://www.lansir.com.tw",
    "author": "LANSIR Technology",
    'depends': ['base','neweb_base','neweb_project'],
    'data': ['security/ir.model.access.csv',
             'views/neweb_sale_inherit4.xml',
             'views/neweb_project_inherit.xml',
             'views/neweb_project_inherit1.xml',
             'views/neweb_project_inherit5.xml',
             'views/neweb_project_inherit6.xml',
             'views/neweb_project_inherit7.xml',
             'views/neweb_partner_menu.xml',
             'views/neweb_sale_inherit5.xml',
             'security/neweb_projext_menu_security.xml',
             'views/neweb_partner_inherit.xml',
             'views/neweb_project_inherit8.xml',
             'wizards/goto_project_wizard.xml',
             'views/neweb_project_inherit9.xml',
             ],
    'application': True,
    'installable': True,
    'description': u'<15>.NEWEB 專案管理擴充模組',
    'summary': u'<15>.NEWEB 專案管理擴充模組',
}
