# -*- coding: utf-8 -*-
# Author : Peter Wu

from odoo import models,fields,api
from odoo.exceptions import UserError

class newebstockininherit1(models.Model):
    _inherit = "stock.picking"

    stockout_customer = fields.Char(size=30, string=u"聯絡人")
    stockout_customer1 = fields.Many2one('res.partner',string=u"連絡人")
    neweb_user_id = fields.Many2one('res.users',string=u"NEWEB聯絡人",default=lambda self:self.env.uid)
    neweb_phone = fields.Char(string=u"NEWEB聯絡人電話")
    neweb_email = fields.Char(string=u"NEWEB聯絡人EMAIL")



    # @api.depends('partner_id')
    # def _stockoutcus(self):
    #     self.stockout_customer = self.partner_id.name

    # @api.onchange('partner_id')
    # def onchangepartner(self):
    #     myparentid = self.partner_id.id

        
    # @api.onchange('stockout_proj_no')
    # def onpartnerchange(self):
    #     myopid = self.env.context.get('stockopid')
    #     mystockrec = self.env['stock.picking'].search([('id', '=', myopid)])
    #     myrec1=self.env['res.partner'].search([('parent_id','=',mystockrec.partner_id.id)])
    #     mypartner1=[]
    #     if myrec1:
    #         for rec in myrec1:
    #             mypartner1.append(rec.id)
    #     return {'domain':{'stockout_customer1':[('id','in',mypartner1)]}}

    def get_sale_info(self):
        myopid = self.env.context.get('stockopid')
        mystockrec = self.env['stock.picking'].search([('id','=',myopid)])
        mysaleno = mystockrec.origin
        if mystockrec.stockout_type=='1':
            myproj = self.env['neweb.project'].search([('sale_no','=',mysaleno)])
            myname=myproj.name
        elif mystockrec.stockout_type=='3':
            myname = self.env['ir.sequence'].next_by_code('neweb_stockin.outb')
        else:
            myname = self.env['ir.sequence'].next_by_code('neweb_stockin.outo')
        self.stockout_proj_no = myname


    @api.onchange('stockout_customer1')
    def onchangeclient(self):
        myrec = self.env['res.partner'].search([('id','=',self.stockout_customer1.id)])
        if myrec:
            self.stockout_custel = myrec.phone
            self.stockout_shipaddr = myrec.street
        myuserid = self.neweb_user_id
        self.neweb_phone = myuserid.employee_ids.work_phone
        self.neweb_email = myuserid.employee_ids.work_email


    @api.onchange('neweb_user_id')
    def onchangeclient1(self):
        if self.neweb_user_id :
            for rec in self:
                rec.update({'neweb_phone':rec.neweb_user_id.employee_ids[0].work_phone,
                            'neweb_email':rec.neweb_user_id.employee_ids[0].work_email})

