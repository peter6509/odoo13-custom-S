# -*- coding: utf-8 -*-
# Author : Peter Wu

from odoo import models,fields,api
from odoo.exceptions import UserError

class newebstockininherit1(models.Model):
    _inherit = "stock.picking"

    neweb_outmemo = fields.Text(string=u"NEWEB出貨備註")



# class newebstickshiplistinherit(models.Model):
#     _inherit = "neweb.stockship_list"
#
#     sequence = fields.Integer()